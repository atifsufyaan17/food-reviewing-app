import os
import json
import requests
import base64


#  curl --location --request POST "https://api.imgur.com/3/image" \
#   --header "Authorization: Client-ID {{clientId}}" \
#   --form "image=R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"

